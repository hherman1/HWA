module Main where
import qualified Lib as L

main :: IO ()
main = L.main
